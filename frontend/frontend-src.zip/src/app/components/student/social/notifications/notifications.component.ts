import { Component, OnInit } from '@angular/core';
import { SocialService, Notification } from '../../../../services/social.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  notifications: Notification[] = [];
  unreadCount = 0;
  isLoading = false;

  constructor(private socialService: SocialService) {}

  ngOnInit(): void {
    this.loadNotifications();
  }

  loadNotifications(): void {
    this.isLoading = true;
    this.socialService.getNotifications().subscribe({
      next: (res) => {
        if (res.success) this.notifications = res.data;
        this.isLoading = false;
      },
      error: () => { this.isLoading = false; }
    });

    this.socialService.getUnreadCount().subscribe({
      next: (res) => { if (res.success) this.unreadCount = res.data; }
    });
  }

  markAsRead(id: number): void {
    this.socialService.markNotificationAsRead(id).subscribe({
      next: (res) => {
        if (res.success) {
          const notif = this.notifications.find(n => n.id === id);
          if (notif) {
            notif.isRead = true;
            this.unreadCount = Math.max(0, this.unreadCount - 1);
          }
        }
      }
    });
  }

  markAllAsRead(): void {
    this.socialService.markAllNotificationsAsRead().subscribe({
      next: (res) => {
        if (res.success) {
          this.notifications.forEach(n => n.isRead = true);
          this.unreadCount = 0;
        }
      }
    });
  }

  getNotificationIcon(type: string): string {
    const icons: { [key: string]: string } = {
      'LIKE': '❤️',
      'COMMENT': '💬',
      'FRIEND_REQUEST': '👥',
      'FRIEND_ACCEPTED': '✅',
      'GROUP_JOIN': '📚',
      'GROUP_POST': '📝',
      'MESSAGE': '✉️'
    };
    return icons[type] || '🔔';
  }

  getTimeAgo(dateString: string): string {
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
    if (diff < 60) return 'À l\'instant';
    if (diff < 3600) return `Il y a ${Math.floor(diff / 60)} min`;
    if (diff < 86400) return `Il y a ${Math.floor(diff / 3600)}h`;
    return `Il y a ${Math.floor(diff / 86400)}j`;
  }
}